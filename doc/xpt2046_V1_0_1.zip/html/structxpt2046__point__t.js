var structxpt2046__point__t =
[
    [ "x", "structxpt2046__point__t.html#a615e1d38edc65fed50d114ede3e0caf4", null ],
    [ "y", "structxpt2046__point__t.html#aae59ec09f2389787aeb5aaa4af8c840d", null ]
];
var unionxpt2046__result__t =
[
    [ "adc_result", "unionxpt2046__result__t.html#aea50f45197f450ed7fa3afc2ec147e81", null ],
    [ "bits", "unionxpt2046__result__t.html#a9c71ab4674e873aa0b39eb8bff80ebb3", null ],
    [ "res0", "unionxpt2046__result__t.html#a9c2824e8992d2da639884512275456a2", null ],
    [ "res1", "unionxpt2046__result__t.html#a6e0b46340b55c1fdd0b3d16465740dd2", null ],
    [ "U", "unionxpt2046__result__t.html#af943c5048548c4d75b14c575602d6961", null ]
];
var annotated_dup =
[
    [ "xpt2046_cal_data_t", "structxpt2046__cal__data__t.html", "structxpt2046__cal__data__t" ],
    [ "xpt2046_control_t", "unionxpt2046__control__t.html", "unionxpt2046__control__t" ],
    [ "xpt2046_filt_data_t", "structxpt2046__filt__data__t.html", "structxpt2046__filt__data__t" ],
    [ "xpt2046_filter_t", "structxpt2046__filter__t.html", "structxpt2046__filter__t" ],
    [ "xpt2046_fsm_t", "structxpt2046__fsm__t.html", "structxpt2046__fsm__t" ],
    [ "xpt2046_point_t", "structxpt2046__point__t.html", "structxpt2046__point__t" ],
    [ "xpt2046_result_t", "unionxpt2046__result__t.html", "unionxpt2046__result__t" ],
    [ "xpt2046_touch_t", "structxpt2046__touch__t.html", "structxpt2046__touch__t" ]
];
var searchData=
[
  ['res0_174',['res0',['../unionxpt2046__result__t.html#a9c2824e8992d2da639884512275456a2',1,'xpt2046_result_t']]],
  ['res1_175',['res1',['../unionxpt2046__result__t.html#a6e0b46340b55c1fdd0b3d16465740dd2',1,'xpt2046_result_t']]]
];

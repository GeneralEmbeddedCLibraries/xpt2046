var searchData=
[
  ['page_48',['page',['../structxpt2046__touch__t.html#a2233da46127c9d8aa81eea0a436ed547',1,'xpt2046_touch_t']]],
  ['pd_49',['pd',['../unionxpt2046__control__t.html#af410624544f7fa516f23fce6caa4e8c0',1,'xpt2046_control_t']]],
  ['pressed_50',['pressed',['../structxpt2046__touch__t.html#ab44d201332afde1c2572a10d17931cd6',1,'xpt2046_touch_t']]]
];

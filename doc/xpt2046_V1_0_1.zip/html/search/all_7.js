var searchData=
[
  ['mode_46',['mode',['../unionxpt2046__control__t.html#ad2c1b81be35fd29c316e84737db568aa',1,'xpt2046_control_t']]]
];

var searchData=
[
  ['samp_5fbuf_176',['samp_buf',['../structxpt2046__filt__data__t.html#a350f1726232cb530067b8723b4dcf594',1,'xpt2046_filt_data_t']]],
  ['ser_5fdfr_177',['ser_dfr',['../unionxpt2046__control__t.html#a5677c4bf70eab31816650ee51648d972',1,'xpt2046_control_t']]],
  ['source_178',['source',['../unionxpt2046__control__t.html#ac25e8ab3d919ba89f80c31b1ee9a3869',1,'xpt2046_control_t']]],
  ['start_179',['start',['../structxpt2046__cal__data__t.html#af037fcba73a6ebc6a64c650899b1d97b',1,'xpt2046_cal_data_t']]],
  ['state_180',['state',['../structxpt2046__fsm__t.html#a7d85e0d5737485066a002c4e895df877',1,'xpt2046_fsm_t']]],
  ['sum_181',['sum',['../structxpt2046__filt__data__t.html#a1b7fe18e1dcb0cdef7e46ae39528a2bb',1,'xpt2046_filt_data_t']]]
];

var searchData=
[
  ['next_170',['next',['../structxpt2046__fsm__t.html#a2a8b45b65761456833034336a0f7fd50',1,'xpt2046_fsm_t']]]
];

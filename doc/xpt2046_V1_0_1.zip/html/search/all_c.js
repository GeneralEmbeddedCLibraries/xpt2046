var searchData=
[
  ['time_59',['time',['../structxpt2046__fsm__t.html#ac6e5860cef7f7bd0a92585ae7e74e35d',1,'xpt2046_fsm_t']]],
  ['tp_60',['Tp',['../structxpt2046__cal__data__t.html#a1de4dc61fde12b886845db4a5d6fb9be',1,'xpt2046_cal_data_t']]]
];

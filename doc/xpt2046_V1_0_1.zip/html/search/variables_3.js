var searchData=
[
  ['done_158',['done',['../structxpt2046__cal__data__t.html#ad2665903f453424a4b7578d2fc422efc',1,'xpt2046_cal_data_t']]],
  ['dp_159',['Dp',['../structxpt2046__cal__data__t.html#a3bcee783e91db9a649949512137f4ad4',1,'xpt2046_cal_data_t']]],
  ['duration_160',['duration',['../structxpt2046__fsm__t.html#a71a972fe0aad78cc854914d83e41b067',1,'xpt2046_fsm_t']]]
];

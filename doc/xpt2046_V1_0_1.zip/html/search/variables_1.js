var searchData=
[
  ['bits_154',['bits',['../unionxpt2046__control__t.html#ae6e6ef996ba936ef0244b1bfce60cfe8',1,'xpt2046_control_t::bits()'],['../unionxpt2046__result__t.html#a9c71ab4674e873aa0b39eb8bff80ebb3',1,'xpt2046_result_t::bits()']]],
  ['busy_155',['busy',['../structxpt2046__cal__data__t.html#a0d786f3b510d5321e42b5e94a4c9d7d2',1,'xpt2046_cal_data_t']]]
];

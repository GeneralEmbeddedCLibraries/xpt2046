var indexSectionsWithContent =
{
  0: "abcdefgmnprstuxy",
  1: "x",
  2: "x",
  3: "x",
  4: "abcdfgmnprstuxy",
  5: "x",
  6: "e",
  7: "x"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Modules"
};


var searchData=
[
  ['xpt2046_5faddr_5ft_187',['xpt2046_addr_t',['../group___x_p_t2046___l_o_w___i_f.html#ga17e9d83710735a596567e76f9d006a00',1,'xpt2046_low_if.h']]],
  ['xpt2046_5fcal_5fstate_5ft_188',['xpt2046_cal_state_t',['../group___x_p_t2046___a_p_i.html#ga801924470637a9b3d1e5fee29784bb6d',1,'xpt2046.c']]],
  ['xpt2046_5fint_5ft_189',['xpt2046_int_t',['../group___x_p_t2046___l_o_w___i_f.html#ga61d6096ef141a02aa797a1f93c0b0f60',1,'xpt2046_low_if.h']]],
  ['xpt2046_5fpd_5ft_190',['xpt2046_pd_t',['../group___x_p_t2046___l_o_w___i_f.html#ga0404c634589aed6aec7b45baadb7ae5e',1,'xpt2046_low_if.h']]],
  ['xpt2046_5fpoints_5ft_191',['xpt2046_points_t',['../group___x_p_t2046___a_p_i.html#ga7c1edb365388d07135ae36b6b16742b6',1,'xpt2046.c']]],
  ['xpt2046_5fstart_5ft_192',['xpt2046_start_t',['../group___x_p_t2046___l_o_w___i_f.html#gac50c868e996f6145270d648e4294649e',1,'xpt2046_low_if.h']]],
  ['xpt2046_5fstatus_5ft_193',['xpt2046_status_t',['../group___x_p_t2046___a_p_i.html#ga5a3c31beab59b8fd9f654b84c1454719',1,'xpt2046.h']]]
];

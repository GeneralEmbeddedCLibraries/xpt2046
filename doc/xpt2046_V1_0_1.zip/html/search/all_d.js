var searchData=
[
  ['u_61',['U',['../unionxpt2046__control__t.html#a9b93bb9c4b0e2bcd0d22a06b2756cfd0',1,'xpt2046_control_t::U()'],['../unionxpt2046__result__t.html#af943c5048548c4d75b14c575602d6961',1,'xpt2046_result_t::U()']]]
];

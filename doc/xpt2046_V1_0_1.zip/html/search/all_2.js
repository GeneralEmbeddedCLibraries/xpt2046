var searchData=
[
  ['col_4',['col',['../structxpt2046__touch__t.html#a65bfc930497f9adeba7cda7379ab40f5',1,'xpt2046_touch_t']]],
  ['cur_5',['cur',['../structxpt2046__fsm__t.html#a54824b5e0f203be4c2c9d20761b73b30',1,'xpt2046_fsm_t']]]
];

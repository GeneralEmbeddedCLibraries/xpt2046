var structxpt2046__filt__data__t =
[
    [ "samp_buf", "structxpt2046__filt__data__t.html#a350f1726232cb530067b8723b4dcf594", null ],
    [ "sum", "structxpt2046__filt__data__t.html#a1b7fe18e1dcb0cdef7e46ae39528a2bb", null ]
];
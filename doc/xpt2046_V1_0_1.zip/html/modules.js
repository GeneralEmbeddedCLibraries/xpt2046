var modules =
[
    [ "XPT2046_API", "group___x_p_t2046___a_p_i.html", "group___x_p_t2046___a_p_i" ],
    [ "XPT2046_LOW_IF", "group___x_p_t2046___l_o_w___i_f.html", "group___x_p_t2046___l_o_w___i_f" ]
];
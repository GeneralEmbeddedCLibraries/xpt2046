var xpt2046_8h =
[
    [ "XPT2046_VER_DEVELOP", "group___x_p_t2046___a_p_i.html#ga7dd41cfb99d14c8e364ed10f720f0c01", null ],
    [ "XPT2046_VER_MAJOR", "group___x_p_t2046___a_p_i.html#ga53ef1cf9f2122a501c5d5b790b29bf84", null ],
    [ "XPT2046_VER_MINOR", "group___x_p_t2046___a_p_i.html#ga990c089ea6ce635150b2f19c235a077b", null ],
    [ "xpt2046_status_t", "group___x_p_t2046___a_p_i.html#ga5a3c31beab59b8fd9f654b84c1454719", [
      [ "eXPT2046_OK", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719ae9172b3968db9b691474e72e7e65c58a", null ],
      [ "eXPT2046_ERROR", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719a68035267e288232a4fd276350b12e302", null ],
      [ "eXPT2046_CAL_IN_PROGRESS", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719abff937a416deef43d79b5d0a4b3e7680", null ]
    ] ],
    [ "xpt2046_get_cal_factors", "group___x_p_t2046___a_p_i.html#gaf62000400874a86bf11247ad6725fcfa", null ],
    [ "xpt2046_get_touch", "group___x_p_t2046___a_p_i.html#ga2981c6a0dbb555e1fd499bb377375c6f", null ],
    [ "xpt2046_hndl", "group___x_p_t2046___a_p_i.html#ga10d370abfaf3209d3cbb9d3fc0a9bf3a", null ],
    [ "xpt2046_init", "group___x_p_t2046___a_p_i.html#ga5797dcad7b1ba9dbcde037d0b05e4409", null ],
    [ "xpt2046_is_calibrated", "group___x_p_t2046___a_p_i.html#gabee67a19e9f744bd65bf870c5cb2db7d", null ],
    [ "xpt2046_is_init", "group___x_p_t2046___a_p_i.html#gab4b193b4f797903ed39f32c8bf657b67", null ],
    [ "xpt2046_set_cal_factors", "group___x_p_t2046___a_p_i.html#ga7ea1339f841f352b99ecfebbd70021a7", null ],
    [ "xpt2046_start_calibration", "group___x_p_t2046___a_p_i.html#ga99c659b5e89fb3c33abbb2b14fb0b8c3", null ]
];
var structxpt2046__touch__t =
[
    [ "col", "structxpt2046__touch__t.html#a65bfc930497f9adeba7cda7379ab40f5", null ],
    [ "force", "structxpt2046__touch__t.html#a1c3f0c208dcbbae157e730bd7dd1b629", null ],
    [ "page", "structxpt2046__touch__t.html#a2233da46127c9d8aa81eea0a436ed547", null ],
    [ "pressed", "structxpt2046__touch__t.html#ab44d201332afde1c2572a10d17931cd6", null ]
];
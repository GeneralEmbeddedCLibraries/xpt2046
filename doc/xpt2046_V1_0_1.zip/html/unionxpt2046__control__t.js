var unionxpt2046__control__t =
[
    [ "addr", "unionxpt2046__control__t.html#ad34aff1f25a6242a65246534338884b0", null ],
    [ "bits", "unionxpt2046__control__t.html#ae6e6ef996ba936ef0244b1bfce60cfe8", null ],
    [ "mode", "unionxpt2046__control__t.html#ad2c1b81be35fd29c316e84737db568aa", null ],
    [ "pd", "unionxpt2046__control__t.html#af410624544f7fa516f23fce6caa4e8c0", null ],
    [ "ser_dfr", "unionxpt2046__control__t.html#a5677c4bf70eab31816650ee51648d972", null ],
    [ "source", "unionxpt2046__control__t.html#ac25e8ab3d919ba89f80c31b1ee9a3869", null ],
    [ "U", "unionxpt2046__control__t.html#a9b93bb9c4b0e2bcd0d22a06b2756cfd0", null ]
];
var group___x_p_t2046___l_o_w___i_f =
[
    [ "xpt2046_control_t", "unionxpt2046__control__t.html", [
      [ "addr", "unionxpt2046__control__t.html#ad34aff1f25a6242a65246534338884b0", null ],
      [ "bits", "unionxpt2046__control__t.html#ae6e6ef996ba936ef0244b1bfce60cfe8", null ],
      [ "mode", "unionxpt2046__control__t.html#ad2c1b81be35fd29c316e84737db568aa", null ],
      [ "pd", "unionxpt2046__control__t.html#af410624544f7fa516f23fce6caa4e8c0", null ],
      [ "ser_dfr", "unionxpt2046__control__t.html#a5677c4bf70eab31816650ee51648d972", null ],
      [ "source", "unionxpt2046__control__t.html#ac25e8ab3d919ba89f80c31b1ee9a3869", null ],
      [ "U", "unionxpt2046__control__t.html#a9b93bb9c4b0e2bcd0d22a06b2756cfd0", null ]
    ] ],
    [ "xpt2046_result_t", "unionxpt2046__result__t.html", [
      [ "adc_result", "unionxpt2046__result__t.html#aea50f45197f450ed7fa3afc2ec147e81", null ],
      [ "bits", "unionxpt2046__result__t.html#a9c71ab4674e873aa0b39eb8bff80ebb3", null ],
      [ "res0", "unionxpt2046__result__t.html#a9c2824e8992d2da639884512275456a2", null ],
      [ "res1", "unionxpt2046__result__t.html#a6e0b46340b55c1fdd0b3d16465740dd2", null ],
      [ "U", "unionxpt2046__result__t.html#af943c5048548c4d75b14c575602d6961", null ]
    ] ],
    [ "xpt2046_addr_t", "group___x_p_t2046___l_o_w___i_f.html#ga17e9d83710735a596567e76f9d006a00", [
      [ "eXPT2046_ADDR_TEMP_0", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a17bce63f3edec04ce82bec1b9b6238e3", null ],
      [ "eXPT2046_ADDR_Y_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a55184fbf7a6d17eb1498cdbecc3ffcd6", null ],
      [ "eXPT2046_ADDR_VBAT", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a36d373edd97eef7b26194ad75ecdd9f2", null ],
      [ "eXPT2046_ADDR_Z1_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00aafab99cae631d3756f6972f9eb19caf6", null ],
      [ "eXPT2046_ADDR_YN", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00afb99a6eb3b7ef888064268861817cd0f", null ],
      [ "eXPT2046_ADDR_X_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00acfb7349aca0d6dcf6915fcba5e4e26d6", null ],
      [ "eXPT2046_ADDR_AUX_IN", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a0865fa3f30d4830fe957f7d054a6a72e", null ],
      [ "eXPT2046_ADDR_TEMP_1", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a65dd1e12a1f72aae3f66b7303ea87281", null ],
      [ "eXPT2046_ADDR_NUM_OF", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00ae36f0ed86da71f552d42cd2bb6481ad1", null ]
    ] ],
    [ "xpt2046_int_t", "group___x_p_t2046___l_o_w___i_f.html#ga61d6096ef141a02aa797a1f93c0b0f60", [
      [ "eXPT2046_INT_ON", "group___x_p_t2046___l_o_w___i_f.html#gga61d6096ef141a02aa797a1f93c0b0f60a73cba8c1c1921964c629d6d6818da03e", null ],
      [ "eXPT2046_INT_OFF", "group___x_p_t2046___l_o_w___i_f.html#gga61d6096ef141a02aa797a1f93c0b0f60a4d7abad5d75afd1d26a43ec88c35ed8c", null ]
    ] ],
    [ "xpt2046_pd_t", "group___x_p_t2046___l_o_w___i_f.html#ga0404c634589aed6aec7b45baadb7ae5e", [
      [ "eXPT2046_PD_POWER_DOWN", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea02f22635e6993a5e86e2b08ede25def6", null ],
      [ "eXPT2046_PD_VREF_OFF", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea5d0d7c63c6bb055dd1bb1c4e226d4dcb", null ],
      [ "eXPT2046_PD_VREF_ON", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea63711b3f8f5f3e5afcfe07fe5e459e1c", null ],
      [ "eXPT2046_PD_DEVICE_FULLY_ON", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5eabb616ede0fc8a9fac1271f4a96d70bff", null ]
    ] ],
    [ "xpt2046_start_t", "group___x_p_t2046___l_o_w___i_f.html#gac50c868e996f6145270d648e4294649e", [
      [ "eXPT2046_START_OFF", "group___x_p_t2046___l_o_w___i_f.html#ggac50c868e996f6145270d648e4294649eaafe7cad332f878183cdcf16f8b9dc02c", null ],
      [ "eXPT2046_START_ON", "group___x_p_t2046___l_o_w___i_f.html#ggac50c868e996f6145270d648e4294649eab035710d1818b2f999e99a6802323405", null ]
    ] ],
    [ "eXPT2046_ADDR_AUX_IN", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a0865fa3f30d4830fe957f7d054a6a72e", null ],
    [ "eXPT2046_ADDR_NUM_OF", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00ae36f0ed86da71f552d42cd2bb6481ad1", null ],
    [ "eXPT2046_ADDR_TEMP_0", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a17bce63f3edec04ce82bec1b9b6238e3", null ],
    [ "eXPT2046_ADDR_TEMP_1", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a65dd1e12a1f72aae3f66b7303ea87281", null ],
    [ "eXPT2046_ADDR_VBAT", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a36d373edd97eef7b26194ad75ecdd9f2", null ],
    [ "eXPT2046_ADDR_X_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00acfb7349aca0d6dcf6915fcba5e4e26d6", null ],
    [ "eXPT2046_ADDR_Y_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00a55184fbf7a6d17eb1498cdbecc3ffcd6", null ],
    [ "eXPT2046_ADDR_YN", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00afb99a6eb3b7ef888064268861817cd0f", null ],
    [ "eXPT2046_ADDR_Z1_POS", "group___x_p_t2046___l_o_w___i_f.html#gga17e9d83710735a596567e76f9d006a00aafab99cae631d3756f6972f9eb19caf6", null ],
    [ "eXPT2046_INT_OFF", "group___x_p_t2046___l_o_w___i_f.html#gga61d6096ef141a02aa797a1f93c0b0f60a4d7abad5d75afd1d26a43ec88c35ed8c", null ],
    [ "eXPT2046_INT_ON", "group___x_p_t2046___l_o_w___i_f.html#gga61d6096ef141a02aa797a1f93c0b0f60a73cba8c1c1921964c629d6d6818da03e", null ],
    [ "eXPT2046_PD_DEVICE_FULLY_ON", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5eabb616ede0fc8a9fac1271f4a96d70bff", null ],
    [ "eXPT2046_PD_POWER_DOWN", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea02f22635e6993a5e86e2b08ede25def6", null ],
    [ "eXPT2046_PD_VREF_OFF", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea5d0d7c63c6bb055dd1bb1c4e226d4dcb", null ],
    [ "eXPT2046_PD_VREF_ON", "group___x_p_t2046___l_o_w___i_f.html#gga0404c634589aed6aec7b45baadb7ae5ea63711b3f8f5f3e5afcfe07fe5e459e1c", null ],
    [ "eXPT2046_START_OFF", "group___x_p_t2046___l_o_w___i_f.html#ggac50c868e996f6145270d648e4294649eaafe7cad332f878183cdcf16f8b9dc02c", null ],
    [ "eXPT2046_START_ON", "group___x_p_t2046___l_o_w___i_f.html#ggac50c868e996f6145270d648e4294649eab035710d1818b2f999e99a6802323405", null ],
    [ "xpt2046_low_if_exchange", "group___x_p_t2046___l_o_w___i_f.html#gafffde81ef3bf4d151c56e778578f0db9", null ],
    [ "xpt2046_low_if_get_int", "group___x_p_t2046___l_o_w___i_f.html#ga19afbf4fb42f25443e4f46ef83d73eb7", null ]
];
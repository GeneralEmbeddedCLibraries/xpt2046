var xpt2046__low__if_8c =
[
    [ "xpt2046_low_if_exchange", "group___x_p_t2046___l_o_w___i_f.html#gafffde81ef3bf4d151c56e778578f0db9", null ],
    [ "xpt2046_low_if_get_int", "group___x_p_t2046___l_o_w___i_f.html#ga19afbf4fb42f25443e4f46ef83d73eb7", null ]
];
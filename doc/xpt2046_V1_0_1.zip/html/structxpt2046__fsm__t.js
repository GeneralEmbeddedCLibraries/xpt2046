var structxpt2046__fsm__t =
[
    [ "cur", "structxpt2046__fsm__t.html#a54824b5e0f203be4c2c9d20761b73b30", null ],
    [ "duration", "structxpt2046__fsm__t.html#a71a972fe0aad78cc854914d83e41b067", null ],
    [ "first_entry", "structxpt2046__fsm__t.html#ac34d323643d6517e26435391862e96cb", null ],
    [ "next", "structxpt2046__fsm__t.html#a2a8b45b65761456833034336a0f7fd50", null ],
    [ "state", "structxpt2046__fsm__t.html#a7d85e0d5737485066a002c4e895df877", null ],
    [ "time", "structxpt2046__fsm__t.html#ac6e5860cef7f7bd0a92585ae7e74e35d", null ]
];
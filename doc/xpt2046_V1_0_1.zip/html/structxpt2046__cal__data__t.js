var structxpt2046__cal__data__t =
[
    [ "busy", "structxpt2046__cal__data__t.html#a0d786f3b510d5321e42b5e94a4c9d7d2", null ],
    [ "done", "structxpt2046__cal__data__t.html#ad2665903f453424a4b7578d2fc422efc", null ],
    [ "Dp", "structxpt2046__cal__data__t.html#a3bcee783e91db9a649949512137f4ad4", null ],
    [ "factors", "structxpt2046__cal__data__t.html#a324f247af4d0f9ec3d8e97262cfee7cb", null ],
    [ "start", "structxpt2046__cal__data__t.html#af037fcba73a6ebc6a64c650899b1d97b", null ],
    [ "Tp", "structxpt2046__cal__data__t.html#a1de4dc61fde12b886845db4a5d6fb9be", null ]
];
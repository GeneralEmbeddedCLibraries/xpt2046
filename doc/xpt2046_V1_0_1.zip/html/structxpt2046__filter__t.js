var structxpt2046__filter__t =
[
    [ "force", "structxpt2046__filter__t.html#a14378832337cd90e9138a8590ba54943", null ],
    [ "x", "structxpt2046__filter__t.html#a6c112ed7a7e96197cf5e6f20ae0d7b14", null ],
    [ "y", "structxpt2046__filter__t.html#a4a00825b32e7e4e478b58a46a6ae58d4", null ]
];
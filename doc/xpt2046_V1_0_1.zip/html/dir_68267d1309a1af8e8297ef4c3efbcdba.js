var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "xpt2046.c", "xpt2046_8c.html", "xpt2046_8c" ],
    [ "xpt2046.h", "xpt2046_8h.html", "xpt2046_8h" ],
    [ "xpt2046_low_if.c", "xpt2046__low__if_8c.html", "xpt2046__low__if_8c" ],
    [ "xpt2046_low_if.h", "xpt2046__low__if_8h.html", "xpt2046__low__if_8h" ]
];
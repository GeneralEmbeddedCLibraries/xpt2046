var searchData=
[
  ['factors_158',['factors',['../structxpt2046__cal__data__t.html#a324f247af4d0f9ec3d8e97262cfee7cb',1,'xpt2046_cal_data_t']]],
  ['first_5fentry_159',['first_entry',['../structxpt2046__fsm__t.html#ac34d323643d6517e26435391862e96cb',1,'xpt2046_fsm_t']]],
  ['force_160',['force',['../structxpt2046__touch__t.html#a1c3f0c208dcbbae157e730bd7dd1b629',1,'xpt2046_touch_t::force()'],['../structxpt2046__filter__t.html#a14378832337cd90e9138a8590ba54943',1,'xpt2046_filter_t::force()']]]
];

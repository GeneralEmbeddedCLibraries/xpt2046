var searchData=
[
  ['g_5fcal_5fcirc_5fattr_161',['g_cal_circ_attr',['../group___x_p_t2046___a_p_i.html#gaab261b4c6baec99cc73eff12744ac309',1,'xpt2046.c']]],
  ['g_5fcal_5fdata_162',['g_cal_data',['../group___x_p_t2046___a_p_i.html#ga892548b6049b80357ecb13628cc38c7f',1,'xpt2046.c']]],
  ['g_5fcal_5ffsm_163',['g_cal_fsm',['../group___x_p_t2046___a_p_i.html#ga670420b51e571ca6796f3e69dc54d921',1,'xpt2046.c']]],
  ['g_5ftouch_164',['g_touch',['../group___x_p_t2046___a_p_i.html#ga9ffd70be440adb93f0f1a84995eb5c9d',1,'xpt2046.c']]],
  ['gb_5fis_5finit_165',['gb_is_init',['../group___x_p_t2046___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385',1,'xpt2046.c']]]
];

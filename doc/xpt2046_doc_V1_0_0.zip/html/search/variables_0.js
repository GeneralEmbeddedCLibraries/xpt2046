var searchData=
[
  ['adc_5fresult_149',['adc_result',['../unionxpt2046__result__t.html#aea50f45197f450ed7fa3afc2ec147e81',1,'xpt2046_result_t']]],
  ['addr_150',['addr',['../unionxpt2046__control__t.html#ad34aff1f25a6242a65246534338884b0',1,'xpt2046_control_t']]]
];

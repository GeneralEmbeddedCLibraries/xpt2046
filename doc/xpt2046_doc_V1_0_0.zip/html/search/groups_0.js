var searchData=
[
  ['xpt2046_5fapi_220',['XPT2046_API',['../group___x_p_t2046___a_p_i.html',1,'']]],
  ['xpt2046_5flow_5fif_221',['XPT2046_LOW_IF',['../group___x_p_t2046___l_o_w___i_f.html',1,'']]]
];

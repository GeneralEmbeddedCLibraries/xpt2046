var searchData=
[
  ['x_182',['x',['../structxpt2046__point__t.html#a615e1d38edc65fed50d114ede3e0caf4',1,'xpt2046_point_t::x()'],['../structxpt2046__filter__t.html#a6c112ed7a7e96197cf5e6f20ae0d7b14',1,'xpt2046_filter_t::x()']]]
];

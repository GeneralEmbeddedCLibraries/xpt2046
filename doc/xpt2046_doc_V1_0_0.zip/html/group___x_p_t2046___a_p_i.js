var group___x_p_t2046___a_p_i =
[
    [ "xpt2046_touch_t", "structxpt2046__touch__t.html", [
      [ "col", "structxpt2046__touch__t.html#a65bfc930497f9adeba7cda7379ab40f5", null ],
      [ "force", "structxpt2046__touch__t.html#a1c3f0c208dcbbae157e730bd7dd1b629", null ],
      [ "page", "structxpt2046__touch__t.html#a2233da46127c9d8aa81eea0a436ed547", null ],
      [ "pressed", "structxpt2046__touch__t.html#ab44d201332afde1c2572a10d17931cd6", null ]
    ] ],
    [ "xpt2046_point_t", "structxpt2046__point__t.html", [
      [ "x", "structxpt2046__point__t.html#a615e1d38edc65fed50d114ede3e0caf4", null ],
      [ "y", "structxpt2046__point__t.html#aae59ec09f2389787aeb5aaa4af8c840d", null ]
    ] ],
    [ "xpt2046_cal_data_t", "structxpt2046__cal__data__t.html", [
      [ "busy", "structxpt2046__cal__data__t.html#a0d786f3b510d5321e42b5e94a4c9d7d2", null ],
      [ "done", "structxpt2046__cal__data__t.html#ad2665903f453424a4b7578d2fc422efc", null ],
      [ "Dp", "structxpt2046__cal__data__t.html#a3bcee783e91db9a649949512137f4ad4", null ],
      [ "factors", "structxpt2046__cal__data__t.html#a324f247af4d0f9ec3d8e97262cfee7cb", null ],
      [ "start", "structxpt2046__cal__data__t.html#af037fcba73a6ebc6a64c650899b1d97b", null ],
      [ "Tp", "structxpt2046__cal__data__t.html#a1de4dc61fde12b886845db4a5d6fb9be", null ]
    ] ],
    [ "xpt2046_fsm_t", "structxpt2046__fsm__t.html", [
      [ "cur", "structxpt2046__fsm__t.html#a54824b5e0f203be4c2c9d20761b73b30", null ],
      [ "duration", "structxpt2046__fsm__t.html#a71a972fe0aad78cc854914d83e41b067", null ],
      [ "first_entry", "structxpt2046__fsm__t.html#ac34d323643d6517e26435391862e96cb", null ],
      [ "next", "structxpt2046__fsm__t.html#a2a8b45b65761456833034336a0f7fd50", null ],
      [ "state", "structxpt2046__fsm__t.html#a7d85e0d5737485066a002c4e895df877", null ],
      [ "time", "structxpt2046__fsm__t.html#ac6e5860cef7f7bd0a92585ae7e74e35d", null ]
    ] ],
    [ "xpt2046_filt_data_t", "structxpt2046__filt__data__t.html", [
      [ "samp_buf", "structxpt2046__filt__data__t.html#a350f1726232cb530067b8723b4dcf594", null ],
      [ "sum", "structxpt2046__filt__data__t.html#a1b7fe18e1dcb0cdef7e46ae39528a2bb", null ]
    ] ],
    [ "xpt2046_filter_t", "structxpt2046__filter__t.html", [
      [ "force", "structxpt2046__filter__t.html#a14378832337cd90e9138a8590ba54943", null ],
      [ "x", "structxpt2046__filter__t.html#a6c112ed7a7e96197cf5e6f20ae0d7b14", null ],
      [ "y", "structxpt2046__filter__t.html#a4a00825b32e7e4e478b58a46a6ae58d4", null ]
    ] ],
    [ "XPT2046_LIMIT_FMS_DURATION", "group___x_p_t2046___a_p_i.html#ga40732c57476af06d74ef3c690c7a1664", null ],
    [ "XPT2046_LIMIT_FMS_MS", "group___x_p_t2046___a_p_i.html#ga1c062556a3aa4812fa59633a745a51f2", null ],
    [ "xpt2046_cal_state_t", "group___x_p_t2046___a_p_i.html#ga801924470637a9b3d1e5fee29784bb6d", [
      [ "eXPT2046_FSM_NORMAL", "group___x_p_t2046___a_p_i.html#gga801924470637a9b3d1e5fee29784bb6dab1f26b8fd6c0e3cf3700c090fa372604", null ],
      [ "eXPT2046_FSM_P1_ACQ", "group___x_p_t2046___a_p_i.html#gga801924470637a9b3d1e5fee29784bb6da7cc46e8c10d897d2bd35d23f8944b463", null ],
      [ "eXPT2046_FSM_P2_ACQ", "group___x_p_t2046___a_p_i.html#gga801924470637a9b3d1e5fee29784bb6da5c657f9b031a04a84164472099b9936e", null ],
      [ "eXPT2046_FSM_P3_ACQ", "group___x_p_t2046___a_p_i.html#gga801924470637a9b3d1e5fee29784bb6da6783ef12bc5bbd348062c5c38c78d49e", null ],
      [ "eXPT2046_FSM_CALC_FACTORS", "group___x_p_t2046___a_p_i.html#gga801924470637a9b3d1e5fee29784bb6da07670ef6aff6106d72d6d23afef3b069", null ]
    ] ],
    [ "xpt2046_points_t", "group___x_p_t2046___a_p_i.html#ga7c1edb365388d07135ae36b6b16742b6", [
      [ "eXPT2046_CAL_P1", "group___x_p_t2046___a_p_i.html#gga7c1edb365388d07135ae36b6b16742b6ac0684f58ecfb418ef5a88925afa1fee4", null ],
      [ "eXPT2046_CAL_P2", "group___x_p_t2046___a_p_i.html#gga7c1edb365388d07135ae36b6b16742b6a9b75630d0ffa308cd4ad132f1c9fb90f", null ],
      [ "eXPT2046_CAL_P3", "group___x_p_t2046___a_p_i.html#gga7c1edb365388d07135ae36b6b16742b6a991749a327dfba4075ade199c627e3e1", null ],
      [ "eXPT2046_CAL_P_NUM_OF", "group___x_p_t2046___a_p_i.html#gga7c1edb365388d07135ae36b6b16742b6a9759bd2f95e541b974e9d9e764938ae8", null ]
    ] ],
    [ "xpt2046_status_t", "group___x_p_t2046___a_p_i.html#ga5a3c31beab59b8fd9f654b84c1454719", [
      [ "eXPT2046_OK", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719ae9172b3968db9b691474e72e7e65c58a", null ],
      [ "eXPT2046_ERROR", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719a68035267e288232a4fd276350b12e302", null ],
      [ "eXPT2046_CAL_IN_PROGRESS", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719abff937a416deef43d79b5d0a4b3e7680", null ]
    ] ],
    [ "eXPT2046_CAL_IN_PROGRESS", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719abff937a416deef43d79b5d0a4b3e7680", null ],
    [ "eXPT2046_ERROR", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719a68035267e288232a4fd276350b12e302", null ],
    [ "eXPT2046_OK", "group___x_p_t2046___a_p_i.html#gga5a3c31beab59b8fd9f654b84c1454719ae9172b3968db9b691474e72e7e65c58a", null ],
    [ "xpt2046_cal_hndl", "group___x_p_t2046___a_p_i.html#gae5ea66dacb2f35f4d020ce37f1dcf258", null ],
    [ "xpt2046_calculate_factors", "group___x_p_t2046___a_p_i.html#ga6fc6817496680191353c8be09b0407d1", null ],
    [ "xpt2046_calibrate_data", "group___x_p_t2046___a_p_i.html#ga17030bd6a502a2b7ecddca074914d6ad", null ],
    [ "xpt2046_clear_cal_point", "group___x_p_t2046___a_p_i.html#gab8378e641beecd857ab5ace446110592", null ],
    [ "xpt2046_filter_data", "group___x_p_t2046___a_p_i.html#ga64cade99bf0cf0f9885e4f1902710935", null ],
    [ "xpt2046_fms_manager", "group___x_p_t2046___a_p_i.html#gabc353584dd999fc28ec6327c401791cf", null ],
    [ "xpt2046_fsm_calc_factors", "group___x_p_t2046___a_p_i.html#gaad2af08b20b2de31a1d4e3b7eded02de", null ],
    [ "xpt2046_fsm_normal", "group___x_p_t2046___a_p_i.html#gac69bb06594665eeb43cb27fb90c6e436", null ],
    [ "xpt2046_fsm_p1_acq", "group___x_p_t2046___a_p_i.html#ga93169c0d22cd29f91b3b77d81662bb15", null ],
    [ "xpt2046_fsm_p2_acq", "group___x_p_t2046___a_p_i.html#gad821d24fd746f123c65cfc04671035bc", null ],
    [ "xpt2046_fsm_p3_acq", "group___x_p_t2046___a_p_i.html#gab2caf36f8edb994a2f09bb7188116497", null ],
    [ "xpt2046_get_cal_factors", "group___x_p_t2046___a_p_i.html#gaf62000400874a86bf11247ad6725fcfa", null ],
    [ "xpt2046_get_touch", "group___x_p_t2046___a_p_i.html#ga2981c6a0dbb555e1fd499bb377375c6f", null ],
    [ "xpt2046_hndl", "group___x_p_t2046___a_p_i.html#ga10d370abfaf3209d3cbb9d3fc0a9bf3a", null ],
    [ "xpt2046_init", "group___x_p_t2046___a_p_i.html#ga5797dcad7b1ba9dbcde037d0b05e4409", null ],
    [ "xpt2046_is_calibrated", "group___x_p_t2046___a_p_i.html#gabee67a19e9f744bd65bf870c5cb2db7d", null ],
    [ "xpt2046_is_init", "group___x_p_t2046___a_p_i.html#gab4b193b4f797903ed39f32c8bf657b67", null ],
    [ "xpt2046_limit_cal_X_data", "group___x_p_t2046___a_p_i.html#ga5fde6f23b460093a55b8e650a4d20d06", null ],
    [ "xpt2046_limit_cal_Y_data", "group___x_p_t2046___a_p_i.html#ga03eb6d1ce8839259999fd4f07d1883fa", null ],
    [ "xpt2046_read_data_from_controler", "group___x_p_t2046___a_p_i.html#ga52482e6a7505a25fd83057d10fccb70c", null ],
    [ "xpt2046_set_cal_factors", "group___x_p_t2046___a_p_i.html#ga7ea1339f841f352b99ecfebbd70021a7", null ],
    [ "xpt2046_set_cal_point", "group___x_p_t2046___a_p_i.html#ga63f6381b005eee0a677e0c6c1e21acf4", null ],
    [ "xpt2046_start_calibration", "group___x_p_t2046___a_p_i.html#ga99c659b5e89fb3c33abbb2b14fb0b8c3", null ],
    [ "g_cal_circ_attr", "group___x_p_t2046___a_p_i.html#gaab261b4c6baec99cc73eff12744ac309", null ],
    [ "g_cal_data", "group___x_p_t2046___a_p_i.html#ga892548b6049b80357ecb13628cc38c7f", null ],
    [ "g_cal_fsm", "group___x_p_t2046___a_p_i.html#ga670420b51e571ca6796f3e69dc54d921", null ],
    [ "g_touch", "group___x_p_t2046___a_p_i.html#ga9ffd70be440adb93f0f1a84995eb5c9d", null ],
    [ "gb_is_init", "group___x_p_t2046___a_p_i.html#ga7aa5c1c01a25e6125e4771126667c385", null ]
];